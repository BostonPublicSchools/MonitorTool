# Geckoboard Data Service
This activity provides a WCF REST data service that exposes Wolfpack HealthCheck result data stored in the Wolfpack database as a native Geckoboard JSON data feed - this means you can create a new custom widget in Geckoboard to display Wolfpack data without having to convert the feed from one format to another - this data feed is formatted specifically for Geckoboard custom widgets. The service has a pluggable data provider design so that it can read the Wolfpack data from any supported Database (currently SqlServer and SQLite) and is extensible for future data stores - just implement the appropriate provider interface.
![](Geckoboard Data Service_geckoboarddataservice.png)

[Geckoboard](http://geckoboard.com/) is a hosted "dashboard", a realtime business status board. It has connectors to a wide range of data feeds such as Twitter, Google Analytics, Pingdom, Basecamp, Highrise & ZenDesk to name a few and you can customise what data is display and how it is visualised - it also supports custom widgets that include [pie charts, line charts, a geck-o-meter (min, max, avg)](http://geckoboard.zendesk.com/entries/274940-custom-chart-widget-type-definitions) and [general textual and RAG](http://geckoboard.zendesk.com/entries/231507-custom-widget-type-definitions) style status indicators.

How does Wolfpack integrate with Geckoboard? HealthCheck results are either boolean or numerical (or both) so can be visualized in the appropriate custom widget. Failures can be displayed as a pie chart per site and in more detail as a breakdown by failure HealthCheck type for a specific site. Any numeric based HealthCheck can be displayed as either a line chart or as a "geck-o-meter" - this displays a min, max and average.

## Supported Widgets
* [Map](Geckoboard-Map) - plot HealthChecks or [AppStats](AppStats) on a Geckoboard map
* [Pie Chart](Geckoboard-Piechart) - display HealthChecks or [AppStats](AppStats) as a pie chart
* [Line Chart](Geckoboard-Linechart) - display HealthChecks or [AppStats](AppStats) as a line chart

**NOTE: The info about the Widgets below is out of date - I am in the process of creating a page per widget (like the Map above). The urls quoted are out of date in most cases - please check the [source code](http://wolfpack.codeplex.com/SourceControl/changeset/view/45e94986edfb#Solutions%2fWolfpack.Core%2fGeckoboard%2fGeckoboardDataService.cs) (WebInvoke attribute) for the actual REST url templates. I will try to get these pages and updated ASAP**

### Line Charts
* **This url has been replaced with a new linechart url in v1.0.8 - TODO update this documentation ASAP**
* _http base address_/geckoboard/linechart/sites/_siteid_/_checkid_ - line chart displays the value of the ResultCount for the site and HealthCheck.
* X and Y axis labels are automatically generated from the min/mid/max dates and values respectively.
* Querystring params to control what data is displayed...
	* **limit** restricts the results to the last n records
	* **sample** is the frequency within the data that a record is selected for the graph.
	* **tag** is a tag that _exactly_ matches the **Tag** property set on a HealthCheck result
	* **scaleup**, **scaledown** - these modify the value. **scaledown** will divide the value by the scale you supply and scaleup will do the reverse. 
	* **scaley** "true" or "false" to apply scale to the y axis labels
	* **scaleydp** sets the dp on the y axis labels
	* Example: you monitor a value once a minute. You could either display the last 300 records OR to display the graph for the last 24 hours set limit=1440 (number of minutes in a day) and sample=10 to select every tenth reading. You can also omit the **sample** parameter to have Wolfpack calculate this to return the maximum number of readings possible.

### Geck-o-meter
* _http base address_/geckoboard/geckometer/sites/_siteid_/_checkid_ - gecko-o-meter displaying the min, max and average of the ResultCount values for the site and HealthCheck specified.

### Number Comparison
* _http base address_/geckoboard/comparison/sites/_siteid_/_checkid_ - displays the last ResultCount value against the previous value for the site and HealthCheck specified.
* _http base address_/geckoboard/days/_yyyy-mm-dd_ - displays the number of days between today and the date supplied. This is useful for creating countdowns to milestones/important dates.

## Configuration
Pretty simple really. All settings are found in the config\activity.castle.config file.  Remember this activity will load the data from the Wolfpack database "AgentData" table (SqlServer or SQLite) - you need to configure your Wolfpack agents/server to publish to either database to begin capturing data before you can display it with Geckoboard.

### GeckoboardDataServiceActivityConfig component
This is the master configuration and is used to control the behaviour of this activity.
* Enabled - true or false, switches the activity on or off respectively.
* ServiceImplementation - the class WCF will create as the service implementation.
* Uri - the endpoint to host this service.
	* Remember this must be internet addressable so ensure you set up port forwarding and firewalls to the machine that is running this Activity inside Wolfpack.
* ApiKey - this is the value you use in the "ApiKey" field of the "Add a new widget" in Geckoboard. Leave this blank to disable this security check.

### GeckoboardDataServiceConfig component
This is the data service configuration. It allows you to select the data provider.
* If you publish your result data to SqlServer then you must set the "DataProvider" property to "SqlServer"
* If you publish your result data to SQLite then you must set the "DataProvider" property to "SQLite"
**NOTE!** In order to cut down on configuration, neither data provider has a configuration component that is exposed in the config file. The only property it provides is the connection string and this is by default the "Wolfpack" connection for the SqlServer Data Provider and "Wolfpack-SQLite" for the SQLite provider. If you do need to change this then you would need to add to appropriate component to the config file.

### ColourPicker component
This controls the colours displayed on geckoboard widgets. It is possible to reserve colours for specific labels so for instance you can ensure that the pie chart segment colours remain consistent. You can also nominate favourite colours - these form the preferred palette of colours to be used before any randomly generated colours. 

* The "Reserved" property takes new dictionary items where the "key" attribute is the label and the value is either a hex RGB value (eg: FF0000 = Red) or a [known system colour](http://msdn.microsoft.com/en-us/library/system.drawing.knowncolor%28v=VS.90%29.aspx) such as "Red". 
* The "Favourites" property takes a list of items where the value is either a hex RGB value or a known system colour.
* If no colours are reserved or made favourite (or you run out of favourites) a random colour will be assigned automatically

## Adding a Geckoboard Widget
>![](Geckoboard Data Service_geckoboard-addwidget.png)
Remember Geckoboard will need a public internet addressable URL for its data feed so make sure you expose the Wolfpack REST service to the internet. At this time Geckoboard does not support any other port than 80 <- Looks like this has been lifted and all ports now work (Thanks to comment below for the info). 

If you are worried about exposing this data to the world then you should add a secret API key - this should also be entered into the activity.castle.config GeckoboardDataServiceActivityConfig ApiKey configuration property to ensure that only authentic requests are served data.

Fill in the other fields as shown on the right (set your own reload time and label though!)

