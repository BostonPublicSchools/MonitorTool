# Line Charts
Display HealthCheck result or AppStats data as a line chart.

![](Geckoboard Linechart_)

## Widget Url

### Result based
This provides a linechart based on the Result value from HealthCheck/AppStat data.
* http://_hostname_/geckoboard/linechart/_check_/_outcome_/
* where...
	* _check_ is the check id to target
	* _outcome_ is the result, values are "success", "failure", "any" (for AppStats always use "any")

### Count based
