# How To, Tutorials
<![](HowTov3_clever.png)
Knowledge is power...one of the hardest things about creating a project like this is the amount of information it generates and how to effectively communicate this to ensure that users can benefit from the hard work put into it.

So...here are a series of guides to leverage the Wolfpack framework to enable you to get monitoring and customising stuff ASAP!

## Coding/Customisation
* [Create an Activity](v3HowToCreateActivity)
* [Create a HealthCheck](v3HowToCreateHealthCheck)
* [Create a Publisher](v3HowToCreatePublisher)
* [Create a Scheduler](v3HowToCreateScheduler)
* [Add pages to the Web UI](v3HowToAddUiPages)
* [Extend the Web Api](v3HowToExtendApi)

## Configuration
* [Agent-to-Agent networking](v3HowToInterAgentMessaging)
* [Storing Notifications in a database](v3HowToStoreNotifications)
