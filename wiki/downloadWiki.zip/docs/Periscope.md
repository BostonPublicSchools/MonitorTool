# Dashboard Support
_...see all the things!..._

<![](Periscope_eye.png)
## Background
It's great that Wolfpack can monitor stuff and count things like the length of a queue - what if you wanted to visualise this information though?...maybe have some sort of dashboard where all this information could be displayed?

This is not a new problem for Wolfpack and it has had support as a data source for the fantastic ["dashboard as a service" Geckoboard](http://www.geckoboard.com/) for a while now.

I had previously resisted having to create my own "dashboard" for Wolfpack - considering slick solutions like Geckobard, [Kibana](http://www.elasticsearch.org/overview/kibana/) and [url@dashku](https___dashku.com) exist already what would be the point? However once a development itch starts it's hard to resist scratching it...so I created a little "proof of concept" app and from there grew Periscope. 

Note: Wolfpack will continue to support Geckoboard and will also soon acquire the ability to push data into Dashku and Kibana.

## Project Periscope
[Periscope is a .Net open source dashboard](https://periscope.codeplex.com/) app/framework. It allows you to define a dashboard via a fluent interface and provides the support for multiple rotating "panels" (screens) and flexible widget implementation - on a panel you can mix your custom html/script widgets with other frameworks such as HighCharts etc. It also supports a web api that allows you to push information to it in realtime (..ahem, from something like Wolfpack!) or anything else that can create a http post request and finally it is powered by SignalR so that realtime means realtime - as the event occurs it is pushed directly to all connected clients.

## Push Notification Support
Wolfpack has a contrib plugin called "DashboardAdapter" (not released yet, sourcecode only in repo) that allows you to push notifications to dashboards you have running - the notification is formatted to the correct push message format and then sent to the dashboard api endpoint. 

DashboardAdapter allows you to define multiple dashboard endpoints and formats to receive push messages in response to a single Wolfpack notification - this is a pretty powerful feature as it allows you to visualise the same notification across different widget types and even different dashboards! For instance a url ping check could be a line graph in a Periscope dashboard AND a simple value display in Dashku!

