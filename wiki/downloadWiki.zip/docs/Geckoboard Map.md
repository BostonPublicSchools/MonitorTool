# Map
Displays pushpins for each stat that matches the selection criteria.

![](Geckoboard Map_geckoboard-map.png) 
## Widget Url
* http://_hostname_/geckoboard/map/_checkid_/_outcome_ 
	* where...
		* _checkid_ is the **FriendlyId** of a HealthCheck
		* _outcome_ is the result. Valid values are "success", "failure", "any"
	* optional querystring params....
		* site= your site id (in role.castle.config)
		* agent = the name of the agent (machine name)
		* tag = any tag value you added as part of the check
## Uses...
This feature can be used in two ways....
# You can provide static longitude/latitude coordinates to each Wolfpack Agent instance; this means you can plot on the map where HealthCheck results have originated from. To do this just set the <Longitude> & <Latitude> elements in the role.castle.config file.
# Using the [AppStats](AppStats) feature you can set the longitude & latitude on an AppStat - so whatever your AppStat represents (an order, a login etc) you can now geo tag it too...eg: put geo coords on your "order" AppStat to plot them on your Geckoboard map.
	* There is a new Geo() extension to the AppStatsEvent object.
{code:xml}
            AppStatsEngine.Publish(new AppStatsEvent()
                                       .PieChart("WolfpackPoll")
                                       .Segment(segmentId)
                                       .One().Geo().Point("51.5017741", "-0.1406510"));
{code:xml}
