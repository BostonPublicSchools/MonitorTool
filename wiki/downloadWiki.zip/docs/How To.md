# How To
This section is designed to provide answers to common questions or scenarios you might have or encounter with Wolfpack. It's split up by functional area and over time I might migrate a section to it's own page. I'll add to this page based on question I field about Wolfpack and my own experience in using it.

## General
_**I have written a custom HealthCheck or other Wolfpack plugin that uses a non .Net dll - I get an error (BadImage) when Wolfpack starts because it is trying to scan this dll for Wolfpack plugins**_
Add the name of your assembly to an <item> in the TypeDiscoveryConfiguration component config in config\role.castle.config file. This will exclude that dll from being scanned by Wolfpack.

## Geckoboard
_**How can I test the Geckoboard Data Service?**_
The Geckoboard Data Service will only accept POST requests (so the it can support the ApiKey feature). If you get an "Http Method Not Allowed" then you are trying to call the url from a browser/curl as a GET - to test it you need to make a POST request.
# Download and install [http://www.fiddler2.com/fiddler2/](Fiddler).
# Run Fiddler and select the "Request Builder" tab
# Set the method drop down to POST
# Enter the your Geckoboard Data Service url
# In the "request headers" section add these two lines "Content-Type: text/plain" and "Content-Length: 3"
# In the "request body" section type some gibberish text - any few characters will do
# Click the "Execute" button - you should see a 200 Ok response

## Publishing
_**I use the Growl Publisher but want to modify the message text and the priority as I don't like the default values.**_
Use a Growl Notification Finaliser - either the built-in Success Finaliser if you want to modify the Growl Notification properties based on the success/failure of a HealthCheck result or the Count Finaliser if you want to modify the notification based on the ResultCount value. You can also combine these Finalisers although the order they will run is undefined.

Alternatively you can create your own Growl Notification Finaliser. This will allow you inject custom logic to inspect the HealthCheck result and then set any property on the Growl Notification that will be passed to the Growl Api.
# Add a reference to Wolfpack.Core.dll
# Create a new class and make it inherit from GrowlNotificationInterceptorBase and implement the "Finalise" method. This method has two parameters, the HealthCheck result and the Growl Notification Api object - this will have the message text and priority already set by the Growl HealthCheck Result Pulisher but you can modify these as you see fit.
# Add a component configuration to the finaliser.castle.config file...
## The "id" attribute needs to be descriptive and unique. 
## The "type" attribute is the fully class name including the namespace in this format; "full classname, assembly name". So if your custom finaliser is called "CustomFinaliser" in the namespace "MyWolfpack.Finalisers" within "MyWolfpack.dll" then the "type" value is "MyWolfpack.Finalisers.CustomFinaliser, MyWolfpack"
## If you need to provide configuration values to your custom Notification Finaliser then add public properties (getter & setter) then add the corresponding item within the <parameters> section in the component configuration.
## The <Check> parameter must be supplied. Use this to associate your Notification Finaliser with a specific HealthCheck (in which case enter the Friendly Id of the HealthCheck, this is found in the check.castle.config file) or use * to associate it with all HealthChecks.

_**I use the Growl Publisher with Prowl to get HealthCheck results on my iPhone but I only want to receive Prowl/iPhone notifications if my HealthCheck returns a value higher/lower than a specific number - eg: free disk space is too low or there is too many messages in a MSMQ Queue.**_
When you register your iPhone with Growl to receive notifications you can set a minimum priority level to forward - eg: only forward the notification to your iPhone if the priority is the same or above the level you specify. With this in mind you can use the builtin Wolfpack **GrowlCountNotificationFinaliser** to set a "Threshold" level (eg: too many messages in an MSMQ Queue) and then set the HigherPriority to "High" (the LowerPriority will default to "Normal"). In Growl - configure your iPhone notifications to only forward if the level is "High (or above)". When you publish to Growl a MSMQ Info HealthCheck result that contains a ResultCount value above or equal to the "Threshold" it will be sent to Growl with priority "High" and "Normal" if it is lower. To configure iPhone notifications when a value goes _below_ the "Threshold" then set the "LowerPriority" to "High" and leave the "HigherPriority" as "Normal" or omit it altogether. Growl itself will receive and display **all** notifications but your iPhone will only have the notification forwarded to it when the priority is set appropriately by the Finaliser.