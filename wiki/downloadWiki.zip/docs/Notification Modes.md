# Notification Modes

**NOT RELEASED YET - WILL BE LAUNCHED IN v3**

TODO...