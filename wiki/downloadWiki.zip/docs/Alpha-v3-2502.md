# Alpha Notes - 2nd April 2014

* Wolfpack v3 alpha core source loaded into repository, as it stands the core is working along with the new NancyFx Web Api and User Interface plus SignalR notifications.
* Wolfpack Contrib projects upgraded and source refreshed
* New RabbitMQ queue check (contrib project)
* Removed Growl as the default publisher - default is now console (formatted json) publisher. Growl publisher is now a "contrib" optional download plug-in.
* User Interface allows you to control the configuration of your Wolfpack instance; create, edit and delete HealthChecks (& other plugins).
* All core HealthChecks have been upgraded to new format. All support the new ISupportConfigurationDiscovery interface.
* Wolfpack v3 (& contrib plugins) are available on [myget.org](https://www.myget.org/gallery/wolfpack_v3) and v3 is available via Chocolatey (see install notes below).

## Play Time!
The quickest way to install is via chocolatey. I have created a [Wolfpack v3 nuget feed on myget.org](https://www.myget.org/gallery/wolfpack_v3) and will be hosting the v3 packages (including the contrib packages) here while in the alpha/beta period...once stable I'll update the official nuget feed.

1. Install [Chocolatey](http://chocolatey.org/) if you haven't got it already (!)
2. Install the Wolfpack package from the v3 myget feed with command below.
{code:powershell}
cinst -packagename wolfpack -source https://www.myget.org/F/wolfpack_v3/
{code:powershell}
3. Once installed either open a new command prompt "Run as administrator" or add the url reservation mentioned below.
4. At the command prompt, type...
{code:powershell}
wolfpack.agent.bat
{code:powershell}
5. open a browser and enter location http://localhost:802/ui - you should see the Wolfpack web UI....
6. Have a play with the new UI - any issues/feedback/requests then start a thread in Discussions/Issues!

Alternatively - download the source and build the Wolfpack solution found in the Solutions folder. Remember to either add the url reservation mentioned below or simply start Visual Studio as administrator otherwise you will get "Access Denied" exceptions when starting Wolfpack.

## Plugins
To download contrib plugins...
1. Stop Wolfpack and open a command prompt at its installation folder.
2. Enter the command below substituting **PACKAGE-NAME-HERE** for the name of a contrib plugin eg: wolfpack.contrib.publishers.email. The important bit is the /feed: switch - this ensures we pick up the latest v3 packages from the myget feed.
{code:powershell}
wolfpack.agent.exe /update:PACKAGE-NAME-HERE /feed:https://www.myget.org/F/wolfpack_v3/
{code:powershell}
3. This will download and install the plugin - restart wolfpack and it should appear in the Configuration UI as a new plugin.

## Notes
### Url Reservation
* The source has the web interface and signalr plugins enabled. These are self-hosted in Wolfpack at **http://localhost:802/ui** and **http://localhost:803/signalr** respectively. If you get an "Access Denied" type messages you might need to put a Url reservation in place (or just run wolfpack.agent.exe as Administrator). 
	* A url reservation ensures an application has rights to access a url (eg: listen on it). [This article](http://www.hanselman.com/blog/WorkingWithSSLAtDevelopmentTimeIsEasierWithIISExpress.aspx) from Mr Hanselman is pretty good for general web setup/permissions and there are some instructions on using netsh to set a url reservation but the command you need is...(remember to run cmd.exe as Admin).
{code:powershell}
"netsh http add urlacl url=http://localhost:802/ user=Everyone"
{code:powershell}



