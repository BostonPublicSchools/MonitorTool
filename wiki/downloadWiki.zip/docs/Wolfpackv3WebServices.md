# Web Services/Api
The Api provides the core REST/Json methods to interact with Wolfpack; this Api is implemented with the NancyFx framework. 
## Notification Api
#### http://localhost:802/api/notification/ + _method below_. 
Methods are **GET** unless specified otherwise.
	* **[Start](Wolfpackv3ApiNotificationStart)** returns the current Wolfpack status including what plugins are running and unhealthy.
	* **[Notify](Wolfpackv3ApiNotificationNotify)** allows you to **POST** a notification to Wolfpack - typically this would be another Wolfpack installation sending notifications to a central Wolfpack instance for storage (see below for more details on agent-to-agent communication).
	* **[List](Wolfpackv3ApiNotificationList)** returns a list of the recent Notifcations received.
	* **[Artifact](Wolfpackv3ApiNotificationArtifact)** returns the artifact associated with a Notification.

## Configuration Api
#### http://localhost:802/api/configuration/ + _method below_. 
Methods are **GET** unless specified otherwise.
	* **[TagCloud](Wolfpackv3ApiConfigurationTagCloud)** returns the tag cloud of available plugins.
	* **[Catalogue](Wolfpackv3ApiConfigurationCatalogue)** returns a detailed list of current configured and discoverable plugins.
	* **[ChangeRequest](Wolfpackv3ApiConfigurationChangeRequest)** allows you to modify, create or delete plugins.
	* **[ApplyChanges](Wolfpackv3ApiConfigurationApplyChanges)** allows you to commit the configuration changes and can optionally restart Wolfpack.
	* **[CancelChanges](Wolfpackv3ApiConfigurationCancelChanges)** allows you to cancel the configuration changes submitted via the **[ChangeRequest](Wolfpackv3ApiConfigurationChangeRequest)** method.

## Agent-to-Agent Communication
![](Wolfpackv3WebServices_Wolfpackv3Agent.png)
# On the remote agent side a plugin provides a robust message delivery mechanism. The default plugin implementation employs a "store and forward" system to ensure messages are delivered in order and when there is a connection.
#  The Wolfpack WebService API is implemented by NancyFx. This provides a tried and tested http platform to build API methods.
# Once the Notification has reached the server another plugin component implements a sequence of checks to ensure that duplicates and out of order messages are dealt with. You can provide a custom plugin implementation to deal with messages should the default behaviour not be right for you.

### Security
Standard mechanisms can now be used to secure the Wolfpack Api & Web UI - a SSL certificate can be used to encrypt the traffic and an Api Key/secret is used to lock down access to trusted clients; you can have multiple Api keys active - grant one per client  to ensure total control over who can access the api.

* A good guide for setting up SSL certificates is this [Scott Hanselman article on IISExpress](http://www.hanselman.com/blog/WorkingWithSSLAtDevelopmentTimeIsEasierWithIISExpress.aspx)...covers the basics you will need to follow.

