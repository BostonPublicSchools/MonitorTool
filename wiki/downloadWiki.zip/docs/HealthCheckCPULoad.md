# CPU Utilisation
Monitors the CPU utilisation as a percentage on the local or a remote machine. This check is a "stream/threshold" based check - it can stream a value and an optional threshold can be set to trigger an alert (represented as a failed check result) should that be breached.
* ResultCount = CPU utilisation %
* Result = false (if threshold set and breached)
## Pre-requisites
* ?
## Configuration
check.castle.config contains the example for this check.
{code:xml}
    <component id="LocalCpuMonitor"
				   lifestyle="singleton"
				   type="Wolfpack.Core.Checks.CpuCheckConfig, Wolfpack.Core">
      <parameters>
        <FriendlyId>LocalCpuMonitor</FriendlyId>
        <Enabled>true</Enabled>
        <StreamData>true</StreamData>
        <Threshold></Threshold>
        <!-- leave blank for local or set to remote machine name -->
        <MachineName></MachineName>
      </parameters>
    </component>
{code:xml}
* **Enabled** set to true to enable the check or false to not run it
* **StreamData** property should be set to "true" to always return the current value - this should be used if you want to constantly monitor (or graph) the processor % utilisation.
* **Threshold** is the % value that will cause a failure result to be generated. This is an optional setting and should be left blank if you do not want to generate alerts if the % goes too high.
* **MachineName** is the name of the machine to execute this check against. Leave blank to check the local machine.

