# MSMQ Queue Not Empty
Slightly modified version of the MSMQ Queue Info check. Check result is based on number of queue items; 
* 0 = success
* > 0 = failure
## Pre-requisites
* Permission to access the MSMQ specified
## Configuration
* Configure the check for queue name and binding file for schedule
