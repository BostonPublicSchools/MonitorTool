# Publishers
<![](Wolfpackv3FeaturesPublishers_publisher.png)
Publisher plugins allow Wolfpack to communicate Notification events to other systems or persist them into storage.

To simplify persistence of Notification, v3 introduces a repository layer - all you need to do is implement the **INotificationRepository** interface and you can plug in to any storage you like.

Wolfpack has out of the box support for SqlServer via an Entity Framework publisher, MongoDb and the good old File System...Mongo is the database of choice though ;-)

* **[MongoDb](https://wolfpackcontrib.codeplex.com/wikipage?title=Wolfpack.Contrib.Publishers.MongoDb)** - (contrib plugin) store Notifications in MongoDb
* **SqlServer** - use SqlServer/Express/LocalDb/Compact to persist Notifications.
* **FileSystem** - store Notifications as text files!