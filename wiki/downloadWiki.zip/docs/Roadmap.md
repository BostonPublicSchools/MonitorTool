# Roadmap
This effectively provides a backlog of ideas for development. If you use Wolfpack and fancy getting your hands dirty developing on it then drop me a line via the [People](http://Wolfpack.codeplex.com/team/view) page or the contact details on the main [Documentation](http://Wolfpack.codeplex.com/documentation) page.

There is also a contrib project running at: [http://wolfpackcontrib.codeplex.com](http://wolfpackcontrib.codeplex.com)

## New Idea?
Add an item to the Discussion tab. Proposals that make the grade will be promoted to "Incubating" where we can shape and finalise the feature and then it can be added to the Backlog below.

## Currently in Development
This is now maintained as a [public Trello board](https://trello.com/b/8gto1kYr).

## Backlog
* Escalation plugin - monitor for alerts and escalate to Level2 if they are not resolved within a specific time.
* Additional publishers...
	* Twitter (Direct Message)
	* Campfire
	* RavenDB
	* Oracle
	* SQL Compact
* Create a "heartbeat" message from each Wolfpack instance - I think this could solve the "no news is good news?" problem that a non-running Wolfpack poses. Essentially an Activity that just pumps an "_I'm alive_" message out.