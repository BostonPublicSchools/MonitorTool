# Sql Query Health Check
This check allows you to provide a FROM clause to a Sql query. Wolfpack will append your "FROM..." to a "SELECT COUNT(*)" to create a scalar query statement - the number of rows returned can then be used to interpret success or failure.
## Pre-requisites
The account identity that Wolfpack runs under will need to have the appropriate Sql LOGIN and SELECT permissions to the Sql entities in your FROM clause.
## Configuration
* The config\check.castle.config file stores the check configuration - the example one that ships with Wolfpack is called "WolfpackDatabaseHasResults".
	* The **ConnectionString** property is now "smart" - this can be an actual connection string OR the name of a connection stored in config\data.connection.config. This means that you can reference a connection string rather than have to replicate it to the various database components that require it making deployment easier.
	* **Remember** when writing your FROM query - you must encode any xml entities such as <>" etc. These are commonly used when writing queries.
	* **InterpretZeroRowsAsAFailure** controls how the row count is interpretted as a result. Set this to true and the check result will indicate a failure if the query returns no rows. Set it to false to make a non zero rowcount a failure.
* Finally remember to associate your check with a scheduler in the config\binding.castle.config file
