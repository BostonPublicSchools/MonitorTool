# Owl Energy Monitor
The [Owl Energy Monitor](http://www.theowl.com/index.php?page=about-owl) is a wireless household/domestic energy monitor - a battery powered sensor unit is clamped around the live mains cable at the distribution box and this broadcasts the cable amp rate. The head unit is a battery powered display that shows all the live readings and stores last week/month/quarter/year data you can scroll through to see if you are using more or less energy.

An additional bit of kit is the [USB Connect](http://www.theowl.com/index.php?page=usb-connect) - this acts as a receiver and plugs into your PC (via USB obviously) to allow you to capture the readings. Each USB Connect can receive data from up to 10 sensors but in a domestic environment I don't know why you would have more than one sensor. 

**Note** in order to continuously receive energy data your PC must be **always switched on** - now, if you are energy conscious then having a PC on 24/7 possibly defeats the objective - however most PC's that are always on (home theatre setups, home automation etc) are pretty low powered (usually < 20/30w) and are obviously there to do another primary job.

## Where to buy
My Owl unit (CM119) was given to me by my parents but I bought the USB Connect (CM120) from Amazon. Here are the Amazon links (**note** these include my affiliate code so I get a 5% cut from Amazon - you don't pay more, Amazon gives me a share of their profit for driving some business their way)
* [Owl CM119 Saving Wireless Power Electricity Smart Monitor](http://www.amazon.co.uk/gp/product/B002C76WTW?ie=UTF8&tag=gadbabdad-21&linkCode=as2&camp=1634&creative=19450&creativeASIN=B002C76WTW)
* [USB Connect](http://www.amazon.co.uk/gp/product/B002H3VUJS?ie=UTF8&tag=gadbabdad-21&linkCode=as2&camp=1634&creative=19450&creativeASIN=B002H3VUJS) (ignore the bad ratings - it's people moaning about the software that comes with it)
or alternatively there are some good deals on [eBay](http://shop.ebay.co.uk/?_nkw=owl+energy+monitor&_sacat=See-All-Categories)

## Wolfpack, Owl & Geckoboard
Wolfpack now includes a HealthCheck to stream the energy data from a PC that has a USB Connect device attached. The data, the min/average/max kw/amps used per minute is captured to a SQLite database by the software that comes with the USB Connect device (The Owl USB Connect windows service). The Wolfpack HealthCheck creates a read-only connection to this database and reads new data rows as the Owl service adds them - Wolfpack only copies the Average kW per minute reading; you then configure the Publishers you wish to send the reading to. Wolfpack provides visualisation of your energy data readings in [Geckoboard](http://geckoboard.com) as it provides several good graphing widgets that fit very well with the data available. A major benefit of using Geckoboard is that you can view your energy readings from any web-browser anywhere in the world as opposed to the standard Owl software that only runs on the PC the USB Connect is attached to.

Where things get interesting is if you have multiple properties to monitor - these could be businesses, properties, offices etc - Wolfpack was designed primarily as a distributed monitoring system so you can run a Wolfpack Agent at each location and publish this data via the WCF Publisher to a central "server" instance of Wolfpack - then view this data on your Geckoboard to view side-by-side charts and graphs of your energy usage from all locations.

![](Owl Energy Monitor_owl-distributed-resized.png)

Here are some examples of displaying Owl Energy data in Geckoboard...

This shows the min, average and max readings across all readings for a sensor. In Geckoboard add a new "Geck-O-Meter" widget and set the properties thus,
* URL Data Feed: http://_your internet ip address_/geckoboard/geckometer/sites/_siteid_/owlenergymonitor?dp=2
* Custom type
* Feed Format = JSON
* Reload Time = 3 mins

![](Owl Energy Monitor_owl-geckoboard-meter.png) 

This shows the last reading received from the sensor and the comparison to the previous sensor reading (not the previously displayed reading). In Geckoboard add a new "Number Comparison" widget and set the properties thus,
* URL Data Feed: http://_your internet ip address_/geckoboard/comparison/sites/_siteid_/owlenergymonitor?dp=2
* Custom type
* Feed Format = JSON
* Reload Time = 3 mins

![](Owl Energy Monitor_owl-geckoboard-spot.png) 

This shows the energy reading (kW) as a linegraph...(the "kettle" annotation was added by me - Wolfpack/Geckoboard isn't clever enough to add this yet!). As you can see energy spikes occur at the obvious times during a 24 hour period, morning and evening. In Geckoboard add a new "Line chart" widget and set the properties thus,
* URL Data Feed: http://_your internet ip address_/geckoboard/linechart/sites/_siteid_/owlenergymonitor?**limit**=1440&**scaleup**=1000&**scaleydp**=2&**scaley**=false
* Custom type
* Feed Format = JSON
* Reload Time = 3 mins

![](Owl Energy Monitor_owl-geckoboard-chart-annotated.png) 

### Typical Scenarios...
Here are a set of scenarios where I see this device and Wolfpack working together...along with a mini guide on configuring Wolfpack. 

#### Scenario: Home
* You have a single Owl Energy Monitor sensor for your entire house
* You want to understand what your household energy usage is and be able to see this anytime
You will need...
* A [Geckoboard](http://geckoboard.com/) account
* A PC running 24/7
* An Owl CM119 unit and CM120 USB Connect device
	* Install the Owl software and sensor - use the Owl software to check that readings are being received by the USB Connect device.
* A single Wolfpack Agent installed
	* See [this guide](getting-started) for more details on installing and running Wolfpack.
	* Enable the Owl Energy Monitor check
		* In config\owl.check.castle.config, "OwlEnergyMonitorCheckConfig" component set the "Enabled" property to "true"
		* Ensure the Owl database (be.db) is in the correct location; check the "ConnectionString" property and adjust the "Data Source" to the correct location (it is set to the default installation location so shouldn't need to be adjusted).
	* Enable the SQLite (or SqlServer) publisher - this allows Wolfpack to capture the data and store a copy of it
		* In config\publisher.castle.config, "SQLiteConfiguration" component set the "Enabled" property to "true"
		* The database location is held in the config\data.connection.config file - currently set to the same folder as the application binaries. You can set a fully qualified path eg: d:\Wolfpack\Wolfpack.db3.
	* Enable the Geckoboard Data Services Activity - this allows your Geckoboard to connect to your Owl Energy data
		* In config\activity.castle.config, "GeckoboardDataServiceActivityConfig" component set the "Enabled" property to "true"
		* The Uri property is where Wolfpack will listen for requests from Geckoboard; remember that this must be on port 80 so 
don't set a custom port number here. Again setup port forwarding on your router to ensure that port 80 traffic will be directed to the PC running this instance of Wolfpack.
	* Make sure you have set the DataProvider for the Geckoboard Data Service. As there are multiple database storage options to publish to now you need to make sure that this Activity queries the correct data source.
		*  In config\activity.castle.config, "GeckoboardDataServiceConfig" component, set the "DataProvider" property to the correct data provider id - valid values are quoted in the comment above this setting
* Ensure that the Wolfpack Geckoboard Data Service is accessible from the internet
	* Setup port forwarding for port 80 to the PC running Wolfpack
* Create a Geckoboard linechart widget
	* The url will be http://_your internet ip address_/geckoboard/linechart/sites/_siteid_/owlenergymonitor?**limit**=1440&**scaleup**=1000&**scaleydp**=2&**scaley**=false
	* Here is an explanation of the querystring parameters (after ?) on the url
		* **limit** = the number of minutes back you want to go. Owl Windows Service records data per minute and Wolfpack copies this across into the Wolfpack database (via WCF/NServiceBus if setup that way). One day is 1440 minutes, two days is 2880 and so on. The number of points plotted on the graph though depends on the sample frequency - you can only plot a maximum of 300 points so the a sample of the data is taken every limit/300 (1440/300) = 3 data rows. Wolfpack will calculate this sample frequency for you or you can set it using the **sample** parameter.
		* **sample** = the row number multiple that the data value will be returned for. Eg: sample=1 means every row will be returned, sample=5 means every fifth row data value will be returned. The rule here is that **limit**/**sample** cannot exceed 300 - if it does Wolfpack will automatically correct it to the best sample frequency possible.
		* **scaleup** & **scaledown** = a factor to multiply (scale up) or divide (scale down) the data (ResultCount) value by. Eg: if the data value is 0.555 and represents kilowatts then **scaleup**=1000 would turn this into 555 watts.
		* **scaleydp** = the number of decimal places to display on the y-axis labels
		* **scaley** = apply the **scaleup** or **scaledown** factor to the y-axis labels so they are also scaled. Default is to scale the y-axis labels. 
		* **tag** = the name of the sensor (as configured in the Owl software). This is stored in the "Tag" field of the Health Check result and by specifing this parameter we can ensure that we only get data for that sensor. If you only have one sensor there is no benefit in providing this parameter and it can be left off the url.
* Start Wolfpack

#### Scenario: Multiple Properties/Businesses
In this scenario there are multiple instances of Wolfpack running - one at each property that has an Owl sensor and one instance will also act as the "server" agent - this instance will collect the sensor data from the other agents; this is done via Http over WCF. The server instance will also expose all your Owl energy data via the Geckoboard Data Service Activity.
* You have a single Owl Energy Monitor sensor in multiple properties/business and you want a dashboard view across then all.
	* Install the Owl software and sensor - use the Owl software to check that readings are being received by the USB Connect device.
* Setting up the "server" instance
	* See [this guide](getting-started) for more details on installing and running Wolfpack.
	* On the "WcfServiceHostConfig" component in config\activity.castle.config set the "Enabled" property to "true"
		* Set the Uri property to the address you want Wolfpack to listen on. Usually localhost will be fine - just adjust the port number as required and remember that if behind a router you will need to set up port forwarding to ensure that remote Wolfpack instances can communicate to this instance.
	* On the "GeckoboardDataServiceActivityConfig" component in config\activity.castle.config set the "Enabled" property to "true"
		* The Uri property is where Wolfpack will listen for requests from Geckoboard - remember that this must be on port 80 so don't set a custom port number here - again setup port forwarding on your router to ensure that port 80 traffic will be directed to the PC running this instance of Wolfpack.
* Setting up the Remote Agents. When you set up Wolfpack on the PC's that have an Owl USB Connect device attached it is important to provide a unique reference to each sensor - this can be done in several ways,
	* Each Agent has a different SiteId (config\role.castle.config)
	* or the Owl Health Check has a different (and unique) FriendlyId (config\owl.check.castle.config)
	* or the sensor name when registered with the Owl software is unique
* Enable the WCF Publisher ("WcfPublisherConfiguration" component in config\publisher.castle.config) and set the Uri property to point to your "server" instance internet address. Eg: If you set the Uri property of the "WcfServiceHostConfig" component on the "server" instance to "http://localhost:802/Wolfpack" then you would need to replace "localhost" with the internet address of the connection running the "server".
	* "Server" instance "WcfServiceHostConfig" Uri property: http://localhost:802/Wolfpack
	* "Remote" instance "WcfPublisherConfiguration" Uri property: http://_internet address of server_:802/Wolfpack
* Start the Wolfpack server instance
* Start each Wolfpack remote instance

### Running
Once you have configured Wolfpack and started all the instances (server/remote) then you should see data start to acculumate in the Wolfpack database. You should see a new row appear for the "OwlEnergyMonitor" result every minute. If you are using SqlServer to hold the AgentData table then just use SQL Studio to view the data - if you are using SQLite then I recommend [SQLiteSpy](http://www.yunqa.de/delphi/doku.php/products/sqlitespy/index) as a good data viewer/query tool.

The best way to see the data is by visualising it in Geckoboard. Instructions for setting up the widgets can be found above.