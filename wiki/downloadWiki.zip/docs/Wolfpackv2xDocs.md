# Wolfpack v2.x Docs (archive)
#### Note: v3 is the official release and support for v2.x has much lower priority!

There is fairly comprehensive documentation to support Wolfpack - however if you think something needs more detail or doesn't explain how it works then please get in touch so I can get you moving and improve it.
## Basics
* [Getting Started](Getting-Started) - information on how to install/uninstall Wolfpack.
	* [Updating Wolfpack](Updating-Wolfpack) - information on how to update your Wolfpack installation and install new plug-ins.
* [Health Checks](Health-Checks) - information on the built-in Health Checks that Wolfpack ships with.
* [Publishers](Configuring-Publishers) - information on how to setup each type of publisher.
	* See [Result Publisher Filters](Result-Publisher-Filters) for information on how to fine tune HealthCheck Result publication.
* [Activities](Activities) - information on the built-in Activities that Wolfpack ships with including how to connect Wolfpack to Geckoboard to create an instant dashboard for your system.
* [How To](How-To) - tries to answer common questions and setup scenarios you have with Wolfpack.
	* [Walkthru - Creating a HealthCheck](Walkthru-Creating-A-HealthCheck) - a full step by step guide to creating a new Health Check component.

## Advanced Features
* [AppStats](AppStats) - use this page to found out how Wolfpack can be used to record your application stats and KPI's.
* [Build Analytics](Build-Analytics) - use this page to set up Wolfpack to monitor your build (TeamCity supported so far) and then extract and display NCover, SpecFlow & StoryQ statistics in Geckoboard.
* [Owl Energy Monitor](Owl-Energy-Monitor) - information on setting up an Owl home/office energy monitor and integrating it with Wolfpack and Geckoboard.
