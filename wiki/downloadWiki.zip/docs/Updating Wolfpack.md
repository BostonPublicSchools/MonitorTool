# Updating Wolfpack
In v2.3 Wolfpack gained the ability to self-update. Inspired by how the NuGet.exe application updates itself I looked at how the NuGet team had done this using their NuGet.Core package and decided that this would be the perfect way to not only deliver a Wolfpack update but also deploy plug-ins directly into your Wolfpack install. Rather than solve this inside the Wolfpack codebase I decided to create "[Sidewinder](http://sidewinder.codeplex.com)" - a NuGet package that any .Net application can use to enable it to self-update or install new components.
## How?
Simple really - each Wolfpack release is available as a full NuGet package - this means that we can use the NuGet infrastructure to deliver it, all we need do is increment the version number and deploy it to the NuGet gallery - Sidewinder will take care of the rest.

From a command prompt...
{code:powershell}
wolfpack.agent.exe /update
{code:powershell}
If an update is available then Sidewinder will download it, backup your current Wolfpack install (you never know!) and instructs Wolfpack to terminate (as it needs to install some new binaries). Once Wolfpack has closed Sidewinder will deploy the new version into your Wolfpack installation folder - restart Wolfpack and it will be running the new version.

### Notes
* The backup folder is called "_backups".and is created in a subfolder of your Wolfpack installation folder.

## Installing new Plug-ins
From a command prompt...
{code:powershell}
wolfpack.agent.exe /update:[name of any nuget package](name-of-any-nuget-package)
{code:powershell}
Any of the Wolfpack.Contrib packages can be installed this way...eg....
{code:powershell}
wolfpack.agent.exe /update:wolfpack.contrib.publishers.console
{code:powershell}
...will download and install the console publisher dll and its associated config file. The config file is installed into the Config\Publishers folder - all you need do is edit the "console.contrib.castle.config" file and set the "Enabled" element to "true" - that's it!