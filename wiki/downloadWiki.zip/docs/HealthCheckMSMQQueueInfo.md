# MSMQ Queue Info
Will return information about a specific MSMQ queue including,
* Exists (= Check Result, exists = true, not exists = false)
* Number of messages
* Datetime stamp of the oldest message
* ResultCount property will contain the number of messages
## Pre-requisites
* Permission to access the MSMQ specified
## Configuration
* Configure the check for queue name and binding file for schedule
