# Getting Started
This provides information on installation and configuration of Wolfpack.

## Installing via Chocolatey
1. Install [Chocolatey](http://chocolatey.org/) if you haven't got it already (!)
2. Install the Wolfpack package with command below....
{code:powershell}
cinst wolfpack
{code:powershell}
3. Once installed either open a new command prompt "Run as administrator" or add the url reservation mentioned below.
4. At the command prompt, type...
{code:powershell}
wolfpack.agent.bat
{code:powershell}
5. open a browser and enter location http://localhost:802/ui - you should see the Wolfpack web UI....
6. Have a play with the new UI - any issues/feedback/requests then start a thread in Discussions/Issues!

## Install via zip
Download the binaries zip. Remember to either add the url reservation mentioned below.

## Download the Source
You can clone the sourcecode repository and run the solution - however you will either need to add the url reservation below or run Visual Studio "as Administrator". 

## Plugins
To download contrib plugins see the notes [here](AddingPluginsv3).

## Notes
### Url Reservation
* The source has the web interface and signalr plugins enabled. These are self-hosted in Wolfpack at **http://localhost:802/ui** and **http://localhost:803/signalr** respectively. If you get an "Access Denied" type messages you might need to put a Url reservation in place (or just run wolfpack.agent.exe as Administrator). 
	* A url reservation ensures an application has rights to access a url (eg: listen on it). [This article](http://www.hanselman.com/blog/WorkingWithSSLAtDevelopmentTimeIsEasierWithIISExpress.aspx) from Mr Hanselman is pretty good for general web setup/permissions and there are some instructions on using netsh to set a url reservation but the command you need is...(remember to run cmd.exe as Admin).
	* Additional help and information about self hosting can be found [here](https://katanaproject.codeplex.com/wikipage?title=Selfhosting).
{code:powershell}
"netsh http add urlacl url=http://localhost:802/ user=Everyone"
{code:powershell}

## Command Line
Wolfpack is based on the TopShelf windows service framework. This means you can run it as either a console application (recommended whilst you evaluate) or install it as an unattended windows service (recommended for real use). All exceptions are logged to the **Wolfpack.log** file in the application folder using Log4Net - check this if you have trouble starting Wolfpack.

To run it as a console application, open a command prompt and type,
{code:powershell}
wolfpack.agent.exe
{code:powershell}
To install and execute it as a windows service running under the **Local System** account, open a command prompt and type,
{code:powershell}
wolfpack.agent.exe /install
{code:powershell}
To install and execute it as a windows service running under the custom account, open a command prompt and type,
{code:powershell}
wolfpack.agent.exe /install /username:[DOMAIN\Account](DOMAIN_Account) /password:[Password](Password)
{code:powershell}
**Remember** the account you run Wolfpack under as a service must have permissions to perform the checks you have configured it for. For instance, if you are using the MSMQ checks the service account must have the correct permissions on the MSMQ in question.

To uninstall it as a windows service, open a command prompt and type,
{code:powershell}
wolfpack.agent.exe /uninstall
{code:powershell}
There are several "profiles" that alter the behaviour of Wolfpack. Supported profile names are,
* **FastStartAgentProfile** - this will asynchronously startup the agent so that control is quickly returned to the Windows Service Control Manager - this stops timeouts occurring when you have a large number of plugins configured and enabled. Access these additional profiles with,
{code:powershell}
wolfpack.agent.exe /profile:[profile name](profile-name)
{code:powershell}

## Configuring Wolfpack
Once installed and you have the http/url reservation in place then fire up a browser and point it to,
#### http://localhost:802/ui
This is the [Wolfpack Web UI](Wolfpackv3WebUI) and the "Configuration" page will allow you to configure the checks, publishers and activity plugins you have installed



