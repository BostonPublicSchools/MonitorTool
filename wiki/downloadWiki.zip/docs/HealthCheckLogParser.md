# LogParser Health Check
[Microsoft LogParser](http://www.microsoft.com/downloads/details.aspx?FamilyID=890cd06b-abf8-4c25-91b2-f8d975cf8c07&displaylang=en) is a fantastic utility for interrogating logging information. "_The world is your database with Log Parser_"...I kid you not - this is taken from the [official docs](http://www.microsoft.com/downloads/details.aspx?FamilyID=890cd06b-abf8-4c25-91b2-f8d975cf8c07&displaylang=en). Basically it allows you to write SQL-esque style statements against lots of textual log data sources (listed below) - it's pretty cool, like an old-school LINQ to "Log Data" type thing.

Stuff you can do with it!....
* Search the Eventlog for entries from specific applications
* Search IIS logs for any status code (eg: 404's)
* Search rss/atom feeds for a specific term
* Search the file system for files that are larger/smaller than a specific size
* Search firewall logs
* Loads more things!!
Check out the LogParser documentation that is installed with LogParser (see Pre-requisites below) for more excellent examples of what you can do with it.

More LogParser resources (links pinched from [Lizard Labs](http://www.lizard-labs.net/PageHtml.aspx?lng=2&PageId=18&PageListItemId=17))...
* [LogParser forums](http://forums.iis.net/default.aspx?GroupID=51)
* [Examples (SQL) queries for IIS Analysis](http://linuxlore.blogspot.com/2006/11/howto-use-microsofts-logparser-to.html)
* [LogParser and Asp.NET](http://support.microsoft.com/kb/910447)
* [Using the Logparser Utility to Analyze Exchange/IIS Logs](http://www.msexchange.org/tutorials/Using-Logparser-Utility-Analyze-ExchangeIIS-Logs.html)

## Supported Input Formats
* CSV
* EVT (Event Log)
* FS (File System)
* IIS
* IIS (W3C)
* REG (Registry)
* TEXTLINE
* TSV
* URLSCAN
* W3C - Examples of log files in this format include,
	* Personal Firewall log files 
	* Microsoft Internet Security and Acceleration Server (ISA Server) log files 
	* Windows Media Services log files 
	* Exchange Tracking log files 
	* Simple Mail Transfer Protocol (SMTP) log files 
* XML
## Unsupported Input Formats
I took a wild stab in the dark at what wouldn't be widely used/required and have not implemented Health Checks based on the following formats. If you're desperate for one of these and can't roll it yourself then drop me a request via the discussion pages and I'll see what can be done - to be honest though they are pretty simple to implement, just look at any of the checks in the Contrib.Checks.LogParser project source to see how simple!
* ADS (Active Directory)
* BIN
* COM
* ETW
* HTTPERR
* IISODBC
* NCSA
* NETMON
* TEXTWORD
## Pre-requisites
In order to use **any** LogParser based Health Check you first need to download and install LogParser onto the machine that will run these checks; LogParser **cannot** be redistributed so you must download and install it yourself - this is the [link](http://www.microsoft.com/downloads/details.aspx?FamilyID=890cd06b-abf8-4c25-91b2-f8d975cf8c07&displaylang=en) to download it from Microsoft. LogParser can query logs from other machines (remotely) but you do not need to install it on the remote machine being queried.

If you are new to LogParser then I recommend using one of the cool GUI's to help you get started with it; I use [Visual LogParser](http://en.serialcoder.net/logiciels/visual-logparser.aspx) but have become aware of [Log Parser Lizard](http://www.lizard-labs.net/PageHtml.aspx?lng=2&PageId=18&PageListItemId=17) which also looks pretty good. Both free/donation-ware.
## Configuration
* From the source code, build the Wolfpack.Contrib.Checks.LogParser project
	* This is my first attempt at a "Contrib" style drop-in configuration for an external dll containing checks
* Copy Wolfpack.Contrib.Checks.LogParser.dll & Interop.MSUtil.dll to the Wolfpack Agent folder. Also copy the files from the "Config" folder, logparser.binding.castle.config & logparser.check.castle.config.
	* The binaries zip will have these files already installed in the correct location.
* Update the logparser.binding.castle.config & logparser.check.castle.config as appropriate.
* In the "check" file "enable" the checks you wish to run. Please consult the LogParser "Documentation" for help with writing the queries.
	* **Remember** when writing your FROM query - you must encode any xml entities such as <>" etc. These are commonly used when writing queries.
	* The parameters to each check are named (almost) the same as the original LogParser parameter - use the LogParser documentation to help explain each one.
* The "binding" file contains bindings for ALL LogParser based checks - just find the ones that contains the checks you have enabled and make sure they bind to the correct "schedule" configuration; the default is "EveryMinute".
* The ResultCount property will contain the number of rows returned by the query.
