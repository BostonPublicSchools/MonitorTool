# FileInfo
Will return information about a specific file including,
* Exists (= Check Result, exists = true, not exists = false)
* CreationTimeUtc
* LastAccessTimeUtc
* LastWriteTimeUtc
* Length (bytes)
* Attributes
* ResultCount property will contain the file size in bytes.
## Pre-requisites
* File system permission to access the file specified
## Configuration
* Configure the check for filename and binding file for schedule