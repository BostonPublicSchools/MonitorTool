# Windows Service State 
This check will compare the state of a windows service to the state you expect the service to be in. If you have mission critical services that must be running then you can use this check to ensure that they are always "Running". 
## Features
* Support for two states, "Running" and "Stopped" (you might also want to ensure a particular service is NOT running).
* Local and Remote - check for services on the same server as Wolfpack or a remote server.
* Multiple services - create a list of services that should be in the same state, this cuts down on configuration.
## Pre-requisites
* Permissions to query/use the Service Control Manager information on the target server
## Configuration
* Set the "ExpectedState" property; valid values are "Running" and "Stopped"
* Set the "Server" property if you need to check services on machine different to the one running the Wolfpack Agent. Leave blank or remove the element to check against the localhost.
* Add a new <item> to the "Services" property for each windows service you wish to monitor. You can use the service display or short name here.
