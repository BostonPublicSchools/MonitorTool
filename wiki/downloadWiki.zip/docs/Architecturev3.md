# Wolfpack Features & Architecture

Wolfpack is a highly modular and componentised system. It has a plugin architecture for extending its primary features such as checks, publishers and activities and it also provides infrastructure or "plumbing" components such as a Logger, IoC container, Message Bus that you can also replace. 

![](Architecturev3_wolfpackv3components.png)

## Health Checks
These act as information collectors - they are the "eyes and ears" of Wolfpack. Each HealthCheck is associated with a host "scheduler" component; the scheduler is responsible for hosting the logic that knows _when_ a HealthCheck should execute.
[Details...](Wolfpackv3FeaturesChecks)

## Schedulers
These components provide the timing or trigger logic used to execute a HealthCheck - they effectively "wrap" a HealthCheck and are responsible for calling it. Each instance of a HealthCheck must be associated with a Scheduler and is run on a dedicated thread.
[Details...](Wolfpackv3FeaturesSchedulers)

## Publishers
Publishers receive notification events from the Health Checks via the central Notification Hub and do "something" with the data...for instance a publisher could store the notification in a database or forward it to Growl or a HipChat room!
[Details...](Wolfpackv3FeaturesPublishers)

## Activities
Activities are agent wide processes. They start with the Agent and usually provide some specific feature or background process. You can easily create a new Activity - just create a new class to implement the **IActivityPlugin** interface.

### Web Services & UI Activity
This activity creates a self-hosted NancyFx powered API exposing REStful methods to interact with a Wolfpack instance using JSON and also bundled with is a Twitter Bootstrap based user interface with views using Knockout to visualise Wolfpack status, activity and control its configuration.
[Details...](Wolfpackv3FeaturesWebInterface)
* Web UI allows you to configure Wolfpack plugins and monitor notifications in real-time with a SignalR activity page.
	* Create, edit and delete plugin configuration
	* Plugins can advertise themselves to the Config UI by implementing the ISupportConfigurationDiscovery interface - they will automatically appear in the UI and you will be able to create a new instance of it.
	* NancyFx interface exposes API methods and html/Knockout views
	* You can create your own plug-ins to extend the Wolfpack API or even add new pages/views - eg: roll your own HTML/Javascript dashboard!

## Notification Hub
This component is responsible for hosting and applying logic that controls notification publication.
[Details...](Wolfpackv3FeaturesNotification)
* The core notification system has had a major remodel and now allows much better control over the logic that determines whether a notification should be published - you can provide custom plugins to assist if the built-in ones don't cover your requirements. The new "NotificationHub" component ensures that notifications are routed through this publication logic.
* Notification message format is unified and simplified - direct support for document databases, just store the notification object!
* SignalR activity plugin will broadcast notifications to all connected clients.

## Message Bus
This component provides an internal pub/sub mechanism and it allows plugins to communicate with each other via event messages. The primary use of the bus is to transport Notification Events from Health Checks (pub) to Publisher (sub) but you can register any pub/sub combination with the Bus. You can also attach Message Interceptors, pre/post delivery to hook into the Bus activity.
[Details...](Wolfpackv3FeaturesMessageBus)

## Configuration Manager
This component is responsible for managing plugin configuration - it relies on multiple configuration repository components to which you can add your own if you want to store plugin configuration in a custom way, eg: database, the cloud etc. By default Wolfpack stores its configuration on the file system as JSON format files but you can easily create new plugins to manage your configuration persistence.
[Details...](Wolfpackv3FeaturesConfiguration)

## Artifact Manager
A new feature of v3 is the ability for a Health Check to create "artifacts". Often a Health Check will produce a large result set as a by-product of raising a Notification - this result set can now be stored as an "artifact" associated with the Notification and can easily be accessed via the Web API methods, all you need is the unique id (Guid) of the Notification and you can download the result set as a CSV file.
[Details...](Wolfpackv3FeaturesArtifacts)
* Artifacts - HealthChecks can now produce large data sets (to support a notification) and have these served up as a CSV download via the WebInterface. 
	* Eg: LogParser check can produce a resultset from a query, create a notification - you can see the resultset captured that triggered the notification.
