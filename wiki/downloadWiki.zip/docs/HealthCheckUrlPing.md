# Url Ping 
This check will ping a url to test it responds and can optionally publish its result based on the response time. You can setup this check to either always publish a result or only if it fails. As a successful ping includes the response time you can use this to monitor variations over time on a dashboard.   
## Features
* Publish only failures or successful pings to track response times.
* Monitor multiple urls, just add a new item to the list.
* Set an optional response time threshold - if the response is slower than this (milliseconds) then publish this as a result failure.
## Pre-requisites
* Outbound http access from the Wolfpack server to the urls
## Configuration
* Add a new <item> to the "Urls" property for each url you wish to monitor.
* Set the "FailIfResponseMillisecondsOver" property to the maximum number of milliseconds you expect the url to respond by. If the url takes longer than this the check will publish a failed result.
	* Leave this property blank, set to 0 (zero) to disable this feature.
* If you are only interested in tracking whether the url is available or not then set the "PublishOnlyIfFailure" property to true (default). If you want to track the response time then set this to false and every ping result will be published; successful pings include the response time in the result "ResultCount" property so you publish these to a database and then mine this information later or connect it up to a dashboard.
