# Wolfpack v3
_...monitor all the things...._

Version 3 of Wolfpack represents a _major_ update - it has been largely rebuilt from the ground up and fixes some of the weaknesses and pain-points from the original design. Wolfpack has been stripped back to a "core" and lost a lot of features in the process...some of these features have been removed for good, some of them will be rebuilt and come back as optional plugin installs (via the contrib project). 

* [Installation and getting started](Installationv3)
	* [Adding plugins](AddingPluginsv3)
* [Features & Architecture](Architecturev3)
* [Dashboard Support](Periscope) _...see all the things!..._
* [How To/Tutorials](HowTov3)

### News
_9th Aug 2014_ - working on an overhaul of the config system. 
* Simplifying and unifying the plugin interfaces/base classes - ultimate goal is to have only a single "PluginId" property rather than the confusing two names/ids at the moment. 
* Also will be adding a proper status page
* Changing the JSON config editor to one that is easier to use. 
* "mute" notifications - useful when you are setting up a new notification and need to de-clutter notifications temporarily.
* Enhancements to the activity page - can now pause the screen to allow you to inspect notifications (also will add click for details).
_25th May 2014_ - v3 is released!

### Changes from v2.x
* Growl publisher exchanged for the Console (json) contrib publisher - growl publisher is now a contrib add-on and console publisher add-on is now part of core and no longer a separate add-on; it is also the default publisher (rather than growl).

### Gone Forever
* NServiceBus as a _notification mechanism_...in fact all traces of NServiceBus from the core. Notification transmission between Wolfpack instances is now rest/json/www based. 
	* Support for NServiceBus healthchecks will remain - the contrib project has a few checks and these will be upgraded to v3 shortly.
* AppStats - Wolfpack now supports an Api method to push a Notification into it so replicating what AppStats effectively provided.