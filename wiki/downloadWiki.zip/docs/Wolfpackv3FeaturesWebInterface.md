# Wolfpack WebServices & UI

The new Wolfpack WebServices Api and User Interface is implemented with self-hosted NancyFx and includes Html/BootStrap/Knockout.js pages and json api methods. At its heart is a RESTful Api with custom markup views to provide the UI...you can now browse your Wolfpack plugins and configure them directly in the UI, plus there are status and help pages and eventually a "gallery" page will allow you to discover new Wolfpack NuGet packages online and download them straight into your Wolfpack installation.

You can create new services that can be dropped into Wolfpack to extend the Api or even just new pages to render Wolfpack data.  As a web based UI you can use any device with a browser to administer your Wolfpack installations. 

Finally a separate activity is available to provide a SignalR powered "push" of notifications to connected web browsers and an Activity page provides a "tail" view of the last 20 notifications generated..see the [User Interface](Wolfpackv3WebUI) page for more details!

![](Wolfpackv3FeaturesWebInterface_UI.png)

## Extensible
You can extend both the Api and UI - add new Api methods and pages to support your custom requirements - there is even a mechanism to allow your page to appear on the main menu bar for quick access.
* [How To Add pages to the UI](v3HowToAddUiPages)
* [How To extend the Api](v3HowToExtendApi)
## More details...
* [Web Services/Api](Wolfpackv3WebServices)
* [User Interface](Wolfpackv3WebUI)

