# Adding Plugins
To download contrib plugins ...

1. Stop Wolfpack and open a command prompt at its installation folder.
2. Enter the command below substituting **PACKAGE-NAME-HERE** for the name of a contrib plugin eg: wolfpack.contrib.publishers.email.
{code:powershell}
wolfpack.agent.exe /update:PACKAGE-NAME-HERE
{code:powershell}
3. This will download and install the plugin - restart wolfpack and it should appear in the Configuration UI as a new plugin.



