## ** Wolfpack v3 is now live! **

# Project Description
Wolfpack aims to be the "swiss army knife" of monitoring. To borrow a line from Etsy..."_if it moves we monitor it, even if it doesn't move we'll monitor it just in case it makes a break for it!_". 

Wolfpack is an extensible .Net windows service based framework for running jobs to monitor your software and system. The data collected can be saved to a database and published to other plugins such as a Growl or HipChat. 

It comes preloaded with some tasks but it's simple to implement your own! A [contrib project](http://wolfpack.codeplex.com) augments this with plugins for email, Growl, HipChat, MongoDb, Powershell plus there is even a [plugin](http://wolfpackcontrib.codeplex.com/wikipage?title=WolfPack.Contrib.Checks.NuGet&referringTitle=Home) to give you alerts when a new version of a NuGet package is released! Wolfpack uses another project of mine called [Sidewinder](http://sidewinder.codeplex.com) to provide a simple update mechanism based on NuGet - [upgrading existing or downloading and installing new plugins](AddingPluginsv3) is super easy and built straight into Wolfpack as a simple command line switch!

Wolfpack has under gone a major rewrite and v3 presents a new platform to build upon with NancyFx providing the core [UI/Api services](Wolfpackv3FeaturesWebInterface) - contrib plugins can also provide UI and be integrated into the existing screens. A richer notification sub-system allows for greater control and shaping of alerts and of course can be customised with your own plugins.
 
## Quick Start

The [Documentation page](documentation) has links to installing, configuring and creating your own custom plug-ins. You will also find a Roadmap link and details of how to stay up to date with project news. For more information about the idea behind the project and a high level view of how it works read on...

## What is it?
Wolfpack is a "system monitor" - however it's focus is aimed squarely at monitoring the touch points your application has with it's infrastructure. From my experience over the last 9 years working with large scale eCommerce and business systems it is remarkable how many critical logs, queues, database tables accumulate or record error or abnormal conditions only for it to go un-noticed until it blows up and becomes a real problem. Early detection using a monitoring system could save you a lot of headaches and allows you to spot issues before they cause trouble.

Wolfpack can also be used to monitor for custom business activity - your KPI's, not just errors. The easy to use "Health Checks" it ships with allow you to quickly set up passive queries to detect these activities and data scenarios plus you can actively pump KPI information directly into Wolfpack via the Api - combined with dashboard like Geckoboard/Kibana/Dashku you can easily visualise your system. Need to see how many high value orders have been placed in the last 3 hours or the number of new users? Simple, push the data to Wolfpack and let it push this to your dashboards via its dashboard adapters (in development - coming soon!). It also has a simple SignalR powered real-time display of all the alerts generated.
## Extensible
Wolfpack aims to provide a simple, extensible system you can easily adapt to monitor your mission critical applications, platforms and systems. It's designed so that you can easily create new plugins to detect and monitor scenarios and situations unique to your systems and business however the plugins provided should be able to cover many of these common "touch points" including...
* IIS logs
* Firewall logs
* Event logs (including queries that join to those on remote machines)
* Many other textual logging formats such as CSV, XML (including making an http call to retrieve the data, eg: RSS, Webservice)
* FileSystem
* Sql Server data (write queries to detect any sort of data condition eg: monitor for orders > £value or not despatched after N days)
* MSMQ
* RabbitMQ (contrib plugin)
* Windows Services
* Web service/site Ping
* System (CPU, Disk) utilisation
* Build/CI (TeamCity at the moment) and the extraction of stats from common build tools like NCover, SpecFlow, StoryQ
* Deployment - Wolfpack can automatically deploy NuGet packages - these can contain your entire website/application or just some unit tests and Wolfpack will detect, download and unpack it, even running the unit tests and sending a notifcation with the results in!
* SSL Certificate expiry - monitor for certificates getting close to expiry and stop embarrassing incidents like the one [SagePay just experienced](http://www.theregister.co.uk/2012/04/26/sagepay_ssl_certificate/).

The core is a .Net Windows Service (based on the Topshelf framework) that has a plug-in architecture for performing any custom activities ("Health Checks") you wish on a set schedule. The data from each Health Check is then "published" via another set of extensible plugins ("Publishers"). You can also create general background activity plug-ins ("Activities") - these just start and stop with the service. Finally it supports the ability to create plugins for when a Health Check executes ("Schedulers" eg: at a fixed time/schedule, triggered by an external event etc).

The full list of extensibility points is,
* **Startup Plugin** - executes at the very beginning of an Agent starting up - use this for general initialisation or Agent configuration
* **Scheduler Plugin** - defines when the associated Health Check plugin will execute
* **HealthCheck Plugin** - the actual test/code to run on the schedule defined by its host Scheduler plugin
* **Publisher Plugin** - these provide the means to communicate the result of a Health Check
* **NotificationRequestFilter** - these allow you to inject logic to decide if the notification should be distributed to all available publisher plugins. 
* **Activity Plugin** - these provide general service wide features - these are usually messenging orientated - eg: create the NServiceBus handlers to receive NSB messages or create a WCF ServiceHost to allow results to be sent to Wolfpack or retrieve data as in the case of the RESTful Geckoboard Data Service Activity.
* **RoleProfile Plugin** - a "role profile" component forms the heart of Wolfpack. A default "Agent" profile is provided and this will load and execute all the components required by the Wolfpack service. You can provide a custom implementation for this core component by simply implementing an interface and passing the name (class name) on the command line switch at startup.
* **Publisher Filters** - these provide a way to attach custom rules to whether a result is published. Filters can be global for either Publisher or Health Check or made specific to a single Publisher/HealthCheck combination.

## Distributed
It's designed so that you can run Wolfpack instances ("Agents") across many servers collecting data and publishing to another "Server" instance where you would republish the data to a database/dashboards/Growl etc  - this is the **Distributed System Monitoring** role it was primarily aimed at.
![](Home_wolfpack_overview.png)

BTW: It's written in C# with Visual Studio 2013 and targets v4.5 .Net framework. It can be run on both x86 and x64 windows operating systems.

### Plugins 
* A full list of HealthChecks (plugins that generate notifications) is [here](Wolfpackv3FeaturesChecks)
	* See this [walk-thru guide](v3HowToCreateHealthCheck) for creating a new Health Check. 
	* Additional HealthChecks are also available in the [Wolfpack.Contrib  Project](http://wolfpackcontrib.codeplex.com/).
* A full list Publishers (plugins that receive/handle notifications) is [here](Wolfpackv3FeaturesPublishers)
	* Additional Publishers are also available in the [Wolfpack.Contrib Project](http://wolfpackcontrib.codeplex.com/).
* A full list Schedulers (plugins that schedule HealthChecks) is [here](Wolfpackv3FeaturesSchedulers)

## Contrib
That's not the end of the story as far as plug-ins go... a separate [Wolfpack Contrib](http://wolfpackcontrib.codeplex.com/) project established by [@RobGibbens](http://twitter.com/RobGibbens) provides additional publishers, healthchecks etc including an email publisher - check it out for more plug-in goodness!

## Getting Started with Wolfpack
The [documentation](documentation) should provide you with everything you need. Any questions or issues please raise them on the appropriate page.


