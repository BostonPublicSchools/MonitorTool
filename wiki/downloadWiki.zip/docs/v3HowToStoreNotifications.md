# Storing Notifications in a database

The default install of Wolfpack does not come pre-configured to store notifications. Notifications are purely transient things (the exception is the Activity page, this has an ActivityTracker component that acts like an in-memory store of notifications...it keeps track of the last 20 notifications and that it what powers the Activity UI page). 

However it is possible to store these Notifications by configuring a special type of "Publisher". There are currently two database publishers that Wolfpack supports as a "Notification Repository" (v3 now has a repository layer so that it can formally interact (read & write) with stored Notifications). 

The core install comes with a SQL publisher (based on Entity Framework) and there is a [contrib publisher based on MongoDb](https://wolfpackcontrib.codeplex.com/wikipage?title=Wolfpack.Contrib.Publishers.MongoDb). 

To enable the SQL publisher, go to the Configuration screen and the "SqlServer" tag should give you a "SqlPublisher" component. Click create and then save (the default settings should work fine). 

The "ConnectionName" config property is "Wolfpackv3" - in the Wolfpack install folder under the Config subfolder there is a "data.connection.config" file with a connection string for "Wolfpackv3" - you can modify this to point to any SqlServer instance. By default it will create a localdb instance. Modify the connection string as required then Accept the configuration change and it should now start storing notifications in the database once Wolfpack restarts. 


