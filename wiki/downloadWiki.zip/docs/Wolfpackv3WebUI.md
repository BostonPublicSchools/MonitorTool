# Web User Interface
The User Interface allows you to interact with your Wolfpack installation.

## Home/Status Page
#### http://localhost:802/ui
Provides a summary of the Wolfpack status and list the plugins, checks publishers etc that are running plus any "unhealthy" plugins that did not initialise correctly at startup.

![](Wolfpackv3WebUI_status.png)

## Activity Page (SignalR)
#### http://localhost:802/ui/activity
No self-respecting .Net system is seen dead without SignalR these days...and Wolfpack is a perfect candidate for some SignalR pixie-dust. Implemented as a simple activity plugin that hooks the internal message bus - Notifications are directly broadcast via a signalr "notification hub" (for those in the SignalR know) to all connected SignalR clients (one of which is the Activity page!).

![](Wolfpackv3WebUI_activity.png)

## Configuration Page
#### http://localhost:802/ui/configure
Quickly find plugins with the Plugins "tag cloud" by selecting/deselecting the tags. Plugins advertise themselves to the tag cloud via the **ISupportConfigurationDiscovery** interface - if a plugin implements this it will automatically appear in the tag cloud and be configurable via the editor.

![](Wolfpackv3WebUI_configure_tagcloud.png)

To create a new plugin instance or edit a running one you need to enter the "Editor" screen - this provides a visual JSON editor - you can edit your plugin config here.

![](Wolfpackv3WebUI_configure_editor.png)

## Send Notification Page
#### http://localhost:802/ui/tools/sendnotification
Pokes a notification into the local Wolfpack instance. This is useful for testing or just general push of some information that requires capturing/broadcasting (to a dashboard for instance).

![](Wolfpackv3WebUI_send_notification.png)

## Diagnostics Page
#### http://localhost:802/ui/tools/diagnostics
**COMING SOON** A page to provide diagnostic information about the running Wolfpack instance including a live (signalr) log output and other stats.

## Help/About Page
#### http://localhost:802/ui/about
A page to provide thanks to anyone that has contributed to the Wolfpack project!


