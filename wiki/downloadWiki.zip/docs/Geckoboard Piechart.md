# Pie Charts
Display HealthCheck result or AppStats data as a pie chart.

![](Geckoboard Piechart_geckoboard_sample-pie.png)

## Widget Url
### All Results
This will provide a count of HealthCheck result failures grouped by SiteId.
* http://_hostname_/geckoboard/piechart/sites

### Failure types for a specific Site
This provides a count of failures by HealthCheck type for the specific site.
* http://_hostname_/geckoboard/piechart/sites/_siteid_
* where...
	* _siteid_ is the name of the site to analyse (this is set in the role.castle.config file)

### Check details
This provides a detailed breakdown of a check or AppStat broken down by Tag.
* http://_hostname_/geckoboard/piechart/_check_/_outcome_/_operation_
* where...
	* _check_ is the check id to target
	* _outcome_ is the result, values are "success", "failure", "any" (for AppStats always use "any")
	* _operation_ controls how the pie chart segment number is generated. Values are...
		* "Count" - this will count the number of results that match
		* "Sum" - this will sum up the ResultCount property of each Tag group
		* "Average" - provides the average ResultCount across each Tag group
		* "Min" & "Max" - provides minimum and maximum respectively across each Tag group
