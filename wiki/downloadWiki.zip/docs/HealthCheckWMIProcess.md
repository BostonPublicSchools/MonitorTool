# WMI Process Not Running
This will simply return the number of processes that match the name specified in the check configuration
* Check result = fail if zero processes running
* ResultCount property will contain the number of matching running processes
## Pre-requisites
* ?
## Configuration
* Configure the check for the process name and binding file for schedule