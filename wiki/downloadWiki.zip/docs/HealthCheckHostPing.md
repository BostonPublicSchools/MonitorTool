# Host Ping (v2.3)
This check will ping a server with an ICMP message to test it responds and can optionally publish its result based on the round-trip response time, eg: only alert if its too slow. You can also setup this check to either always publish a result (if you wanted to capture the response times) or only if it fails. As a successful ping includes the response time you can use this to monitor variations over time (perfect in Geckoboard as a Linechart or Geck-o-meter via the Wolfpack Geckoboard Data Service Activity plugin!)  
## Features
* Publish only failures or successful pings to track response times.
* Set an optional response time threshold - if the response is slower than this (milliseconds) then publish this as a result failure.
* Multiple servers can be pinged.
## Pre-requisites
* ICMP firewall ports open and target server configured to respond.
## Configuration
* Add servers to the list to be checked...just add a new "item"...
{code:xml}
				<hosts>
					<list>
						<item>localhost</item>
					</list>
				</hosts>
{code:xml}
* Set the "timeout" property to the maximum number of milliseconds you expect the response by. If the response takes longer than this the check will publish a failed result.
	* Leave this property blank, set to 0 (zero) or omit from the xml config to disable this feature.
* If you are only interested in tracking whether the server is available or not then set the "publishOnlyIfFailure" property to true (default). If you want to track the response time then set this to false and every ping result will be published; successful pings include the round-trip response time in the result "ResultCount" property so you publish these to a database and then visualise them with the Wolfpack Geckoboard Data Service Activity as a linegraph or Geck-o-meter.
