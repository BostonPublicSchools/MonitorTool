# Updates/News...
Stay up to date with the latest developments,
* On Twitter ([@followjimbobdog](http://twitter.com/followjimbobdog)) and with [#wolfpackmonitor](http://twitter.com/#search?q=%23wolfpackmonitor)
* My blog, [http://jimblogdog.blogspot.com/search/label/wolfpack](http://jimblogdog.blogspot.com/search/label/wolfpack).
* Follow this codeplex project - just visit the [Home](Home) tab and click the "follow" link in the top right panel and also subscribe via the RSS link.
* The [Roadmap](Roadmap) page lists new ideas and thinking about the future design
	* The "TODO" list is maintained as a [public Trello board](https://trello.com/b/8gto1kYr)

# Wolfpack v3
* [v3 Documentation](Wolfpackv3Docs)
_10th May 2014_ v3 is live!

v3 is now the official release and replaces v2.x. There are many breaking changes between the two versions but v3 offers significant improvements including a User Interface and the new Notification Hub feature.

# Wolfpack v2.x
The main docs index page has been archived [here](Wolfpackv2xDocs).

# Roadmap/Incubating
I've got some longer term ideas for Wolfpack and I'm starting to get suggestions for features and improvements from Wolfpack users - so I have started a [Roadmap](Roadmap) page to keep a track of them and give a clear view of the direction it's going in. To help flesh out individual ideas I'll start a discussion thread [here (prefixed "Incubating")](http://Wolfpack.codeplex.com/Thread/List.aspx) - this gives everyone a chance to contribute to the discussion of what it is and how to design/develop it.
# Contrib
Wolfpack now has a [contrib project](http://wolfpackcontrib.codeplex.com)! :) Started by Rob Gibbens ([@RobGibbens](http://twitter.com/#!/robgibbens)) it extends Wolfpack to provide new Health Checks and Publishers (email, MongoDb) and goes without saying the NuGet packages are available too (just search for "wolfpack")! Nice one Rob!
# Thank you!
* Massive thanks to the awesome folks at [JetBrains](http://www.jetbrains.com/) for supporting the [Open Source Software community](http://www.jetbrains.com/devnet/sponsorship/open-source/) and granting the Wolfpack project licences to its superb ReSharper and dotTrace products..."_Wolfpack is developed faster with ReSharper!_"
* [Pixel Mixer](http://pixelmixer.ru/) for the cool ![](Documentation_agent_small.png) logo/icon (via the awesome [http://www.iconfinder.com](http://www.iconfinder.com))
* Paul (@geckoboard) for help getting me hooked up to his incredible [Geckoboard](geckoboard.com) dashboard
* [VisualPharm](http://www.visualpharm.com/) for the AppStats line chart icon
* [Oliver Scholtz](http://linux.softpedia.com/developer/Oliver-Scholtz-93.html) for message graphic
* Rob Gibbens for his work on the NuGet packages and contrib projects (Oracle, Mongo etc)