# FolderInfo
Will return information about a specific folder including,
* Exists (= Check Result, exists = true, not exists = false)
* CreationTimeUtc
* LastAccessTimeUtc
* LastWriteTimeUtc
* FileCount (immediate children)
* FolderCount (immediate children)
* Attributes
* ResultCount property will contain the number of files
## Pre-requisites
* File system permission to access the folder specified
## Configuration
* Configure the check for folder name and binding file for schedule
