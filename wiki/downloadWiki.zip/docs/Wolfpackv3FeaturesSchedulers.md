# Schedulers
<![](Wolfpackv3FeaturesSchedulers_scheduler.png)

This page contains all the information you need to know about the Schedulers...






* 24/7 Scheduler - provides total control when your health checks execute over a week period. You can set as many times per day as you like and which days including shorthand configuration to set weekdays, weekends and every day of the week; these can all be combined to provide a complete custom schedule. Eg: you could configure a check to run on set times weekdays, set additional times for monday, wednesday & saturday and have no timings on sunday.
* Interval Scheduler - provides a simple interval based scheduler; executes the associated HealthCheck every N seconds.
It's a simple interface to implement to create your own activities to run any .Net code you like. Custom schedules are also possible by implementing another interface.



