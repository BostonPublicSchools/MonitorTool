# Api: Notification - Artifact
#### http://localhost:802/api/notification/artifact/{NotificationId}
This method allows you to download a Notification artifact as a CSV file. If a HealthCheck supports generation of artifacts and it is enabled in the check configuration then the artifact csv file will be written out to disk; calling this Api method will allow you to download the file.

* **{NotificationId}** is the **Id** property (Guid) of a Notification.